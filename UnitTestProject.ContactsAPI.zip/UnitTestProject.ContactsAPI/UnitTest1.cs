using Fluent.Infrastructure.FluentModel;
using ManageContacts.API.Controllers;
using ManageContacts.Models;
using ManageContacts.Repository;
using ManageContacts.Repository.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System.Collections.Generic;

namespace UnitTestProject.ContactsAPI
{
    [TestClass]
    public class UnitTest1
    {
        private IContactRepository repository;
        public UnitTest1()
        {
            var options = new DbContextOptionsBuilder<ContactsDB>()
            .UseSqlServer("Data Source=localhost; Initial Catalog=ContactsDB; Integrated Security=true;").Options;
            ContactsDB dB = new ContactsDB(options);
            this.repository = new ContactRepository(dB);
        }

        [TestMethod]
        public void GetAllContacts_ShouldReturnAllContacts()
        {
            var testContacts = GetTestContacts();
            
            var controller = new ContactsAPIController(this.repository);
            List<Contact> result = (List<Contact>)controller.Get();
            Assert.IsTrue(result.Count > 0);
            //Assert.AreEqual(testContacts.Count, result.Count);
        }

        [TestMethod]
        public void GetContact_ShouldReturnCorrectContact()
        {
            var testContacts = GetTestContacts();
            var controller = new ContactsAPIController(this.repository);

            var result = controller.Get(4);
            //Assert.IsNotNull(result);
            Assert.AreEqual(testContacts[3].FirstName, result.FirstName);
        }
        private List<Contact> GetTestContacts()
        {
            var testContacts = new List<Contact>();
            testContacts.Add(new Contact { Id = 1, FirstName = "Shrikant", LastName = "Mule", Email = "abc@12.com", PhoneNo = "123", Status = true });
            testContacts.Add(new Contact { Id = 2, FirstName = "Dipali", LastName = "Mule", Email = "asd", PhoneNo = "123", Status = false });
            testContacts.Add(new Contact { Id = 3, FirstName = "abc-changed", LastName = "xyz", Email = "sanc@gda.com", PhoneNo = "123", Status = true });
            testContacts.Add(new Contact { Id = 4, FirstName = "cdc", LastName = "weradfasd", Email = "sdl@sdf.com", PhoneNo = "123456", Status = true });

            return testContacts;
        }
    }
}
