﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ManageContacts.Models;
using ManageContacts.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ManageContacts.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactsAPIController : ControllerBase
    {
        private readonly IContactRepository repository;
        public ContactsAPIController(IContactRepository repository)
        {
            this.repository = repository;
        }
        public IEnumerable<Contact> Get()
        {
            return this.repository.Get();
        }
        [HttpGet("{id}")]
        public Contact Get(int id)
        {
            return this.repository.Get(id);
        }

        // POST: api/Default
        [HttpPost]
        public IEnumerable<Contact> Post(Contact contact)
        {
            this.repository.Add(contact);
            return this.repository.Get();
        }

        // PUT: api/Default/5
        [HttpPut]
        public IEnumerable<Contact> Put(Contact contact)
        {
            this.repository.Update(contact);
            return this.repository.Get();
        }

        // DELETE: api/Default/5
        [HttpDelete]
        public IEnumerable<Contact> Delete(int id)
        {
            Contact contact = this.repository.Get(id);
            contact.Status = false;
            this.repository.Update(contact);
            return this.repository.Get();
        }
    }
}
