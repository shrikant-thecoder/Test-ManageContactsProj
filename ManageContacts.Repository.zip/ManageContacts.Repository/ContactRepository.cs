﻿using ManageContacts.Models;
using ManageContacts.Repository.Infrastructure;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManageContacts.Repository
{
    public class ContactRepository : IContactRepository
    {
        private ContactsDB db;
        public ContactRepository(ContactsDB db)
        {
            this.db = db;
        }
        public void Add(Contact entity)
        {
            db.Contacts.Add(entity);
            db.SaveChanges();
        }

        public void Delete(Contact entity)
        {
            db.Contacts.Attach(entity);
            db.Entry(entity).State = EntityState.Modified;
            db.SaveChanges();
        }

        public List<Contact> Get()
        {
            return db.Contacts.ToList();
        }

        public Contact Get(int id)
        {
            return db.Contacts.Where(x => x.Id == id).FirstOrDefault();
        }

        public void Update(Contact entity)
        {
            db.Contacts.Attach(entity);
            db.Entry(entity).State = EntityState.Modified;
            db.SaveChanges();
        }
    }
}
