﻿using ManageContacts.Models;
using Microsoft.EntityFrameworkCore;

namespace ManageContacts.Repository.Infrastructure
{
    public class ContactsDB : DbContext
    {
        public ContactsDB(DbContextOptions<ContactsDB> options) : base(options)
        { }

        public DbSet<Contact> Contacts { get; set; }

    }
}
